import os
from dataclasses import dataclass


@dataclass
class RPAConfig:
    rpa_id: str
    host: str
    port: int
    region: str = "default"
    heartbeat_interval: int = 5


def load_from_env() -> RPAConfig:
    rpa_id = os.getenv("RPA_MONITOR_ID", "").strip()
    host = os.getenv("RPA_MONITOR_HOST", "").strip()
    port_str = os.getenv("RPA_MONITOR_PORT", "").strip()

    if not rpa_id or not host or not port_str:
        raise RuntimeError(
            "Variáveis obrigatórias: RPA_MONITOR_ID, RPA_MONITOR_HOST, RPA_MONITOR_PORT"
        )

    region = os.getenv("RPA_MONITOR_REGION", "default").strip()
    heartbeat = int(os.getenv("RPA_MONITOR_HEARTBEAT", "5"))

    return RPAConfig(
        rpa_id=rpa_id,
        host=host,
        port=int(port_str),
        region=region,
        heartbeat_interval=heartbeat,
    )

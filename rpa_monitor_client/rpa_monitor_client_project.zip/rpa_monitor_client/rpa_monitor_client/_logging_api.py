from typing import Optional
from ._client import _RPAMonitorClient

_client_instance: Optional[_RPAMonitorClient] = None


def set_client(client: Optional[_RPAMonitorClient]) -> None:
    global _client_instance
    _client_instance = client


class _RPALogProxy:
    """Proxy simples para expor métodos de log."""

    def info(self, msg: str, regiao: Optional[str] = None) -> None:
        if _client_instance:
            _client_instance.log_info(msg, regiao=regiao)

    def warn(self, msg: str, regiao: Optional[str] = None) -> None:
        if _client_instance:
            _client_instance.log_warn(msg, regiao=regiao)

    def error(
        self,
        msg: str,
        exc: Optional[BaseException] = None,
        regiao: Optional[str] = None,
    ) -> None:
        if _client_instance:
            _client_instance.log_error(msg, exc=exc, regiao=regiao)


rpa_log = _RPALogProxy()

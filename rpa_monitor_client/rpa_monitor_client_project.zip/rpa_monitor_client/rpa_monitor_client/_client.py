import socket
import threading
import time
from datetime import datetime, timezone
from typing import Optional


class _RPAMonitorClient:
    """Cliente interno para enviar heartbeats e logs."""

    def __init__(
        self,
        rpa_id: str,
        host: str,
        port: int,
        region: str = "default",
        heartbeat_interval: int = 5,
    ):
        self.rpa_id = rpa_id
        self.host = host
        self.port = port
        self.region = region
        self.heartbeat_interval = heartbeat_interval

        self._sock: Optional[socket.socket] = None
        self._running = False
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

    def start(self) -> bool:
        if not self._connect():
            return False

        self._running = True
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop,
            daemon=True,
        )
        self._heartbeat_thread.start()
        return True

    def stop(self) -> None:
        self._running = False
        if self._heartbeat_thread and self._heartbeat_thread.is_alive():
            time.sleep(0.2)
        with self._lock:
            if self._sock:
                try:
                    self._sock.close()
                except Exception:
                    pass
                self._sock = None

    def _connect(self) -> bool:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((self.host, self.port))
            s.settimeout(5.0)
            with self._lock:
                self._sock = s
            print(f"[rpa-monitor-client] Conectado em {self.host}:{self.port} ({self.rpa_id})")
            return True
        except Exception as e:
            print(f"[rpa-monitor-client] Erro ao conectar: {e}")
            return False

    def _ensure_connected(self) -> bool:
        with self._lock:
            ok = self._sock is not None
        if ok:
            return True
        return self._connect()

    def _heartbeat_loop(self) -> None:
        while self._running:
            try:
                if self._ensure_connected():
                    self._send_message(
                        op="01",
                        nivel="INFO",
                        payload="alive",
                        regiao=self.region,
                    )
            except Exception as e:
                print(f"[rpa-monitor-client] Falha no heartbeat: {e}")
            time.sleep(self.heartbeat_interval)

    def log(
        self,
        mensagem: str,
        nivel: str = "INFO",
        regiao: Optional[str] = None,
    ) -> None:
        try:
            if self._ensure_connected():
                self._send_message(
                    op="02",
                    nivel=nivel,
                    payload=mensagem,
                    regiao=regiao or self.region,
                )
        except Exception as e:
            print(f"[rpa-monitor-client] Falha ao enviar log: {e}")

    def log_error(
        self,
        mensagem: str,
        exc: Optional[BaseException] = None,
        regiao: Optional[str] = None,
    ) -> None:
        txt = mensagem
        if exc is not None:
            txt = f"{mensagem} | {type(exc).__name__}: {exc}"
        self.log(txt, nivel="ERROR", regiao=regiao)

    def log_warn(self, mensagem: str, regiao: Optional[str] = None) -> None:
        self.log(mensagem, nivel="WARN", regiao=regiao)

    def log_info(self, mensagem: str, regiao: Optional[str] = None) -> None:
        self.log(mensagem, nivel="INFO", regiao=regiao)

    def _send_message(
        self,
        op: str,
        nivel: str,
        payload: str,
        regiao: Optional[str] = None,
        nonce: str = "",
        sig: str = "",
    ) -> None:
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        reg = regiao or self.region
        line = f"V1|{op}|{self.rpa_id}|{ts}|{reg}|{nivel}|{payload}|{nonce}|{sig}\n"

        with self._lock:
            if not self._sock:
                raise RuntimeError("Socket não conectado")
            self._sock.sendall(line.encode("utf-8"))
